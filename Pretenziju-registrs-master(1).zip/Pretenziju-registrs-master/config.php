<?php
define('LOGFILE','C:\Program Files\EasyPHP-Devserver-16.1\eds-www\Pretenziju-registrs\mlog.log');